exports.register = (req, res) => {
  // registration logic here
  res.send('Register endpoint');
};

exports.login = (req, res) => {
  // login logic here
  res.send('Login endpoint');
};

exports.me = (req, res) => {
  // return user info here
  res.send('Me endpoint');
};