    require('dotenv').config();
    const express = require('express');
    const cors = require('cors');
    const app = express();

    // CORS configuration for production
    const allowedOrigins = [
        'http://localhost:3000',
        'https://yourdomain.com', // Replace with your actual domain
        'https://www.yourdomain.com' // Replace with your actual domain
    ];

    app.use(cors({ 
        origin: function (origin, callback) {
            // Allow requests with no origin (like mobile apps or curl requests)
            if (!origin) return callback(null, true);
            if (allowedOrigins.indexOf(origin) !== -1) {
                callback(null, true);
            } else {
                callback(new Error('Not allowed by CORS'));
            }
        },
        credentials: true 
    }));
    app.use(express.json());

    app.use('/api/auth', require('./routes/auth'));
    app.use('/api/users', require('./routes/users'));

    // Health check
    app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

    const PORT = process.env.PORT || 4000;
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));